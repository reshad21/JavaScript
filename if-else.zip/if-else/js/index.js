

		var btnClick=document.getElementById("btn-click");
		var paragraph=document.getElementById("paragraph");
		var extraText=document.getElementById("extra-text");

		btnClick.addEventListener("click",function(){
			
			if(btnClick.innerHTML=="see more"){
				btnClick.innerHTML="see less";
			}
			else{
				btnClick.innerHTML="see more";
			}

		});
